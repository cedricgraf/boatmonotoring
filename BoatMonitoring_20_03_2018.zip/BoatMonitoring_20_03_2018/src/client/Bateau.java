package client;

public class Bateau {
	
	private String nom;
	
	private String Type ;
	
	private String portstationnement;
	
	private String immatriculation;
	
	private int positiongps;
	
	private String Etatactuel;
	
	
	

}
