package client;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Abonne {

		
	
	DonneesAbonne donneesAbonne ;
	Socket  clientTcp ;
	
	



public  Abonne(String login,String pwd,Socket clientTcp){
		

	
		this.donneesAbonne= new DonneesAbonne(login,pwd);
		this.donneesAbonne.setEstConnecte(true);
		this.clientTcp=clientTcp;
	}





public DonneesAbonne getDonneesAbonne() {
	return donneesAbonne;
}





public void setDonneesAbonne(DonneesAbonne donneesAbonne) {
	this.donneesAbonne = donneesAbonne;
}





public Socket getClientTcp() {
	return clientTcp;
}





public void setClientTcp(Socket clientTcp) {
	this.clientTcp = clientTcp;
}	

}
