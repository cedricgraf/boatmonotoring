package systeme;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

import client.Abonne;

/** La banque : dans cet exercice, une banque correspond a un compte bancaire unique,
 *  pour des raisons didactiques */
public class SystemeCentral extends Observable implements IBanque {

	private int port = 6666;
	private int hport = 7777;
	/** Les serveurs pour la mise en oeuvre de connexion a distance */
	public ArrayList<ServeurTCP> serveurs = new ArrayList<ServeurTCP>();
	
	
	/*  liste des abonnes*/
	
	ArrayList<Abonne> listeAbonnes ;
	
	
	
	public ArrayList<Abonne> getListeAbonnes() {
		return listeAbonnes;
	}


	public void setListeAbonnes(ArrayList<Abonne> listeAbonnes) {
		this.listeAbonnes = listeAbonnes;
	}


	
	private ArrayList<String> historiqueOperations;
	
	
	public SystemeCentral() {

		listeAbonnes =new  ArrayList<Abonne>();
		typeOperation = "Aucune operation";
		historiqueOperations = new ArrayList<String>();
		
		
		
		
	}
	
	

	
	public void lancerSystemeCentral() {
		serveurs.add(new ServeurTCP(this, new ProtocoleInscriptionConnexionHistorique(), port ));
		serveurs.add(new ServeurTCP(this, new ProtocoleAfficherHistorique(), hport));
		for(ServeurTCP s : serveurs ) {
				s.start();
		}
	}

	public String toString() {
		return "La Banque possede un compte avec la somme de " + getLeCompte().getSomme();
	}

	public synchronized int demandeRetrait(int unRetrait) {
		return strategyretrait.demandeRetrait(unRetrait, this);
	}

	public synchronized int demandeDepot(int unDepot) {
		return strategydepot.demandeDepot(unDepot, this);
	}

	
	public String getTypeOperation() {
		return typeOperation;
	}

	public CompteBancaire getLeCompte() {
		return leCompte;
	}

	public void setTypeOperation(String s) {
		typeOperation = s;
	}

	public void faireOperation(String string) {
		this.historiqueOperations.add(string);
		this.setTypeOperation(string);
		this.setChanged();
		this.notifyObservers();
	}

	public void setStrategyretrait(String typeRetrait) {
		if (typeRetrait.equals(StrategieUI.retraitSimple))
			strategyretrait = new DemandeRetraitSimple();
		else if (typeRetrait.equals(StrategieUI.retraitPlafond)) 
			strategyretrait = new DemandeRetraitPlafond(100);
	}
	
	public void setStrategydepot( String typeDepot ) {
		if (typeDepot.equals(StrategieUI.depotSimple))
			strategydepot = new DemandeDepotSimple();
		else if (typeDepot.equals(StrategieUI.depotTemporise)) 
			strategydepot = new DemandeDepotTemporise();
	}
	
	public ArrayList<String> getHistoriqueOperations() {
		return historiqueOperations;
	}
	
	
	public void ajouterAbonne(String nom, String prenom){
		this.listeAbonnes.add(new Abonne(nom,prenom)) ;
	}
	public void ajouterAbonne(String nom, String prenom,Socket client){
		this.listeAbonnes.add(new Abonne(nom,prenom,client)) ;
	}	
	public boolean verification(String login, String pwd){
		
		
		for (Abonne ab:this.listeAbonnes){
			if(ab.getLogin().equals(login) && ab.getMotDePasse().equals(pwd)){
				
				ab.setEstConnecte(true);
				return true ;
			}
			
			
			
		}
		
		return false;
		
		
	}
	
	
	
}
