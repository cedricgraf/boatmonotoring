package systeme;
import java.io.InputStream;

import java.io.OutputStream;
import java.net.Socket;



public interface IProtocole {

	public void execute( IContext aContext ,Socket  clientTcp );
	
}
