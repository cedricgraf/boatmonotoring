package boat;

public class Alarm extends Event {
	public boolean isAlarm(){
		return true;
	}

}
