package boat;
import java.util.Observable;
import java.util.*;

public class Boat extends Observable implements Iboat,Runnable {
	
	public Position position = new Position();
	
	
	private int securityraduis;
	
	
	private String name ; 
	
	private String Imatricule; 
	
	private State currentState;
	public Boat(){
		Monitoring  aState = new Monitoring();
		currentState = aState;
	}
	
	public Boat(State aState){
		currentState = aState;
		
	}
	public void setState(State aState){
		currentState = aState;
	}
	public State getState(){
		return currentState;
	}
	public void step(Event anEvt){
		currentState.execute(this, anEvt);
	}
	public String toString(){
		return "Boat in "+getState();
	}
	
	public String getName(){
		return name;
	}
	
	public String getMatricule(){
		return Imatricule;
	}
	
	public synchronized State ChangeState(State currentstate){
		State newstate;
		newstate = currentstate;
		System.out.println("mon etat actuel est "+newstate);
		this.setChanged();
		this.notifyObservers();
		return newstate;
		
	}
	
	
	public int SecurityRaduis(){
		return securityraduis=40;
	}
	
	public synchronized void run(){
		int time = 360;
		Random rind = new Random();
		while ( time == 360){
			
			position.setPosition(1+rind.nextInt(100)); //on regarde le GPS 
			
			if (position.getPosition() > 50){
				this.step(new Alarm());
				this.ChangeState(this.getState()); /// on utilise la ChangeState pour notifier les observer
				///ajout à retirer 
				
				System.out.println( "le dit bateau qu'il a été volé son état est"+this.getState());
				
				///
				
				
			}
			
			if(position.getPosition() <=50){
				if(this.getState()== new Tracking()){
					this.step(new Stopalarm());
					this.step(new Activated());
					this.ChangeState(this.getState());
					///ajout a retirer 
					
					System.out.println( "le bateau dit qu'il a été retrouvé son état est"+this.getState());
					///
				}
			}
			time = time-1;
		}
		                       
	}
	
		
	
}
	
	

