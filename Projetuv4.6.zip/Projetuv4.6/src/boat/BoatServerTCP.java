package boat;
import java.io.*;
//## dependency net 
import java.net.*;
//## auto_generated
import java.util.*;
//## dependency Socket 
import java.net.Socket;


public class BoatServerTCP {
	/**
     * 
     * 
     * * <br><br>@poseidon-object-id&nbsp;[Ic5495em10906c7af27mm7da0]
     * * <!-- end-UML-doc -->
     * * @generated "UML vers Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
    */
    private int numeroPort;		//## attribute numeroPort 
    
    /**
     * 
     * 
     * * <br><br>@poseidon-object-id&nbsp;[Ic5495em10906c7af27mm7da7]
     * * <!-- end-UML-doc -->
     * * @generated "UML vers Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
    */
    public Iboat Theboat;		//## link banqueCentrale 
    
    /**
     * 
     * 
     * * <br><br>@poseidon-object-id&nbsp;[Ic5495em10906c7af27mm7db0]
     * * <!-- end-UML-doc -->
     * * @generated "UML vers Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
    */
    private Socket clientSocket;		//## link clientSocket 
    
    
    // Constructors
    
    /**
     * 
     * 
     * * <br><br>@poseidon-object-id&nbsp;[Ic5495em10906c7af27mm7d99]<br>@param&nbsp;unNumeroPort&nbsp;
     * * <!-- end-UML-doc -->
     * * @param unNumeroPort
     * * @generated "UML vers Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
     * @param unNumeroPort
    */
     BoatServerTCP(int unNumeroPort) {
        numeroPort = unNumeroPort;
    }
    
    /**
     * 
     * 
     * * <br><br>@poseidon-object-id&nbsp;[Ic5495em10906c7af27mm7d8c]<br>@return&nbsp;
     * * <!-- end-UML-doc -->
     * * @return
     * * @generated "UML vers Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
    */
    public Iboat  getTheboat() {
        return Theboat;
    }
    
    /**
     * 
     * 
     * * <br><br>@poseidon-object-id&nbsp;[Ic5495em10906c7af27mm7d80]
     * * <!-- end-UML-doc -->
     * * @generated "UML vers Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
    */
    public void go() {
        ServerSocket serverSocket = null;
        try {
        	serverSocket = new ServerSocket(numeroPort);
        } catch (IOException e) {
        	System.out.println("Could not listen on port: " + numeroPort + ", "
        			+ e);
        	System.exit(1);
        }
        
        for (int nbClient = 0; nbClient <= 3; nbClient++) {
        	try {
        		/* **************** Attente du serveur pour l'acces a +sieurs Clients  ****************/
        		System.out
        				.println(" Attente du serveur pour la communication d'un client ");
        		clientSocket = serverSocket.accept();
        	} catch (IOException e) {
        		System.out.println("Accept failed: " + 6666 + ", " + e);
        		System.exit(1);
        	}
        	ServerSpecifique st = new ServerSpecifique(clientSocket, this);
        	st.start();
        }
        
        try {
        	serverSocket.close();
        } catch (IOException e) {
        	System.out.println("Could not close");
        }
    }
    
    /**
     * 
     * 
     * * <br><br>@poseidon-object-id&nbsp;[Ic5495em10906c7af27mm7d92]<br>@param&nbsp;uneBanque&nbsp;
     * * <!-- end-UML-doc -->
     * * @param uneBanque
     * * @generated "UML vers Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
     * @param uneBanque
    */
    public void setBanqueCentrale(Iboat unBoat) {
        Theboat = unBoat;
    }
    
    /**
     * 
     * 
     * * <br><br>@poseidon-object-id&nbsp;[Ic5495em10906c7af27mm7d86]<br>@return&nbsp;
     * * <!-- end-UML-doc -->
     * * @return
     * * @generated "UML vers Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
    */
    public String toString() {
        return "Serveur de banque avec une somme de :"
        		+ Theboat ;
    }


}
