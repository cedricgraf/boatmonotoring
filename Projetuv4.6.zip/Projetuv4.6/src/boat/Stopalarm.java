package boat;

public class Stopalarm extends Event {
	public boolean isStopalarm(){
		return true;
	}

}
