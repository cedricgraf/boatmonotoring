package boat;

public interface IBoatPC {
	
	boolean connexionaucentral();
	
	
	void  deconnexionaucentral();
	
	void donnermaposition(Position unecordonn);
	
	State monetat(Boat ceboat);

}
