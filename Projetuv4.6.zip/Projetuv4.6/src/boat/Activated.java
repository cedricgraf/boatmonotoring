package boat;

public class Activated extends Event {
	public boolean isActivated(){
		return true;
	}
	

}
