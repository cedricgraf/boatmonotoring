package boat;

public abstract class Event {
	public boolean isActivated(){
		return false;
	}
	public boolean isDesactivated(){
		return false;
	}
	public boolean isAlarm(){
		return false;
	}
	public boolean isStopalarm(){
		return false;
	}
	public String toString(){
		return "Event Name:"+this.getClass().getName();
	}

}
