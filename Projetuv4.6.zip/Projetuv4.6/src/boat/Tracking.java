package boat;

public class Tracking extends State {
	@Override
	public void execute(Boat myBoat, Event trigger){
		if(trigger.isStopalarm()){
			System.out.println("Tracking State executing with trigger:"+trigger);
			myBoat.setState(new Monitoring());
		}
		if(trigger.isStopalarm()){
			System.out.println("Tracking State executing with trigger:"+trigger);
	}

	}
}