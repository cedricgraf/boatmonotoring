package boat;

import java.util.*;

public class MainClient {

	public static void main(String[] args) {
		String myS = null;
		Scanner aSC = new Scanner(System.in);
		BoatClientTCP myClient = new BoatClientTCP("192.168.0.48", 6666);
		
		BoatClientTCP leClient = new BoatClientTCP("192.168.0.48", 6666);
		
		myClient.connexionServeur();
		Position lapos = new Position();
		
		Boat bateau1 = new Boat();
		Boat bateau2 = new Boat();
		
		bateau1.run();
		bateau2.run();
		
        BoatPC Pc = new BoatPC(myClient,lapos, bateau1);
        BoatPC Pc1 = new BoatPC(leClient,lapos, bateau2);
        //DerniereOperationGUI OperGUI = new DerniereOperationGUI(MAGICBANQUE);
        System.out.println("le 1er bateau");
        
        Pc.run();
        System.out.println("le 2er bateau");
        Pc1.run();


			//for (int i = 0; i < 5; i++) {
				//System.out.println(" Saisir une chaine ");
				//bateau1.run();
				
				//myClient.transmettreChaine(Integer.toString(bateau1.position.getPosition()));

				//if ( myClient.connexionTransmettreChaine(myS) == null ) break;

			//}

			//aSC.close();

			//myClient.disconnectFromServer();

	}
}
