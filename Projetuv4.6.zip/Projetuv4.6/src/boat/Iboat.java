package boat;

public interface Iboat {
	public State ChangeState(State currentstate);
	
	public int SecurityRaduis();
	
	public String getMatricule();
	
	public String getName();

}
