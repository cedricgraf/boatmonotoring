package boat;

public class Desactivated extends Event {
	
	public boolean isDesactivated(){
		return true;
	}

}
