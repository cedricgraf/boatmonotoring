package boat;


public class Position  {
	private int coordonnees;
	
	public  Position() {
		coordonnees = 0;
	}
	
	
	public void setPosition(int myposition ){
		this.coordonnees = myposition;
	}
	 
	public int getPosition(){
		return coordonnees;
	}

}

