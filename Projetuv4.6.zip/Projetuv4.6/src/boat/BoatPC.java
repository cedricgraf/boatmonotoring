package boat;

import java.util.Observable;
import java.util.Observer;

public class BoatPC implements IBoatPC, Observer {
	
	private Position unecordon;
	
	public BoatClientTCP leClient;
	
	public Boat unBoat;
	
	
	public  BoatPC(BoatClientTCP unClient, Position currentpos, Boat ceBoat){
       Position unecordon = new Position();
       
        leClient = unClient;
        
        unBoat = ceBoat;
        unBoat.addObserver(this);
	}
	
	public boolean connexionaucentral() {
        return leClient.connexionServeur();
	}
	
	public void  deconnexionaucentral(){
		leClient.deconnexionServeur();
	}
	
	public void donnermaposition(Position unecordon){
		System.out.println("demande position");
		int a=unecordon.getPosition();
		System.out.println("ok ");
		System.out.println(a);
		if (unecordon.getPosition() != 0){
			String valeurRetour = leClient.transmettreChaine("maposition à evolué " + unecordon);
			System.out.println("le bateau est à la position "+valeurRetour);
			}
		else{
			String valeurRetour = leClient.transmettreChaine("maposition n'a pas changé " + unecordon.getPosition());
			System.out.println("le bateau est à la position "+valeurRetour);
		}
		
	}
	
	//public State 
	
	public State monetat (Boat unBoat){
		
	    State defaultState = new Standby();
		State mystate = unBoat.getState();
		if( mystate != defaultState){
		leClient.transmettreChaine("mon nouvel etat " + mystate);
		System.out.println("je suis actuellement dans l'etat"+mystate);
		return mystate;
		}
		else{
			leClient.transmettreChaine("je suis toujours dans l'etat " + defaultState);
			return defaultState;
		}
		
	}
      
	 public void update(Observable o, Object arg) {
	        this.monetat(((Boat) o));
	    }
	
	
	 public synchronized void run(){
		 int i = 10;
		 this.connexionaucentral();
		 while (i==100);{
		 
		 State defaultState = new Standby();
		 State mystate = unBoat.getState();
		 if( mystate != defaultState){
		 leClient.transmettreChaine("mon nouvel etat " + mystate);
		 System.out.println("je suis actuellement dans l'etat"+mystate);
		 //return mystate;
		 }
		 else{
			leClient.transmettreChaine("je suis toujours dans l'etat " + defaultState);
			//return defaultState;
		 }
		 i=i-10; 
		 } 
		 
	 }

}
