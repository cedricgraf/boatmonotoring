package boat;

public class Monitoring extends State{
	@Override
	public void execute( Boat myBoat, Event trigger){
		if(trigger.isDesactivated()){
			System.out.println("Monitoring state executing with trigger:" +trigger);
			myBoat.setState(new Standby());
		}
	
		if(trigger.isActivated()){
			System.out.println("Monitoring State executing with trigger:"+trigger);
			
		}
		if(trigger.isAlarm()){
			System.out.println("Monitoring state executing with trigger:" +trigger);
			myBoat.setState(new Tracking());
		}
	
}

}
