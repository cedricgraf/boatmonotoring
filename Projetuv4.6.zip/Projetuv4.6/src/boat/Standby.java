package boat;

public class Standby extends State {
	@Override
	public void execute (Boat myBoat, Event trigger){
		if(trigger.isActivated()){
			System.out.println("Standby state executing with trigger:" +trigger);
			myBoat.setState(new Monitoring());
		}
		if (trigger.isDesactivated()){
			System.out.println("Standby State executing with trigger:"+trigger);
		}
	}
}
