package boat;

public abstract class State {
	
	public abstract void execute( Boat myBoat , Event trigger);
	public String toString(){
		return "State Name:"+this.getClass().getName();
	}
}
