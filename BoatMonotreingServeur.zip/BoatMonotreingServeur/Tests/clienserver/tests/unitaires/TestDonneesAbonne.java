package clienserver.tests.unitaires;

import static org.junit.Assert.assertNotNull;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import client.DonneesAbonne;
import client.DonneesBateau;



public class TestBateau {
	
	static DonneesAbonne donneesAbonne;
	
	@BeforeClass
	public static void beforeClass(){
		System.out.println("before class");
		donneesAbonne= new donneesAbonne("jordane","123") ;

	}
			
	@AfterClass
	public static void afterClass(){
		System.out.println("after class");

	}
	
	@Before
	public void before() {
		System.out.println("before");
	}

	@After
	public void after() {
		System.out.println("after");
	}

	@Test
	public void testNotNull(){
		
		assertNotNull(donneesAbonne);

		
	}
	
	
	@Test public void testChangeTestNom(){
		
		donneesAbonne.setNom("NGAMI");
		assertTrue(donneesAbonne.getNom().equals("NGAMI"));	
}
	
	@Test
	public void testAddOperation {
		
		int tailleAvant=donneesBateau.getListeOperations().size() ;
		
		donneesAbonne.add("Connexion");
		assertTrue(donneesAbonne.getListeOperations().get(tailleAvant)=="Connexion");// test sur l'op�ration ajout�e
		
		assertTrue(donneesAbonne.getListeOperations().size()==tailleAvant+1);	
		
	}
	
	
	@Test
	public void testAccountIsCreated() {
		assertNotNull(aServer.getMonCompte());
	}
	
}
