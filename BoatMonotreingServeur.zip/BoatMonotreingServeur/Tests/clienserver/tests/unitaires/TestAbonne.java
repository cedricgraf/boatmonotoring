package clienserver.tests.unitaires;

import static org.junit.Assert.assertNotNull;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import client.DonneesBateau;



public class TestBateau {
	
	static DonneesBateau donneesAbonne;
	
	@BeforeClass
	public static void beforeClass(){
		System.out.println("before class");
		bateau= new DonneesAbonne("1") ;

	}
			
	@AfterClass
	public static void afterClass(){
		System.out.println("after class");

	}
	
	@Before
	public void before() {
		System.out.println("before");
	}

	@After
	public void after() {
		System.out.println("after");
	}

	@Test
	public void testNotNull(){
		
		assertNotNull(donneesBateau);
		assertTrue(aServer.isAlive());
		
	}
	
	@Test public void testChangId(){
		donneesBateau.setId("2");
		assertTrue(donneesBateau.getId().equals("2"));
		
	}
	

	@Test
	public void testAddOperation {
		
		int tailleAvant=donneesBateau.getListeOperations().size() ;
		
		donneesBateau.add("Connexion");
		assertTrue(donneesBateau.getListeOperations().get(tailleAvant)=="Connexion");// test sur l'op�ration ajout�e
		
		assertTrue(donneesBateau.getListeOperations().size()==tailleAvant+1);
		

		
		
	}
	
	
	@Test
	public void testAccountIsCreated() {
		assertNotNull(aServer.getMonCompte());
	}
	
}
