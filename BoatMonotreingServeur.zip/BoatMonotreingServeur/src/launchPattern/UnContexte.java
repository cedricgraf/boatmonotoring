package launchPattern;

import servPattern.IContext;

public class UnContexte implements IContext {

}
