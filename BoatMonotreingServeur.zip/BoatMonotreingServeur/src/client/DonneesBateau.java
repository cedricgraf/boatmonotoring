package client;

import java.util.ArrayList;


import java.util.List;

public class DonneesBateau {

		
	private String id ;
	private String type;

	private  boolean estConnecte ;
	private ArrayList<String> listeOperations ;
	private String dateDeCreation ; 
	
	
	
	public DonneesBateau(String id){
		
		
		this.id=id ;
		
	}
	
	
	
	
	public void ajouterOperation(String operation){
		
		listeOperations.add(operation) ;	
	}
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setEstConnecte(boolean estConnecte) {
		this.estConnecte = estConnecte;
	}

	public List<String> getListeOperations() {
		return listeOperations;
	}





	public void setListeOperations(ArrayList<String> listeOperations) {
		this.listeOperations = listeOperations;
	}



	public String getDateDeCreation() {
		return dateDeCreation;
	}




	public void setDateDeCreation(String dateDeCreation) {
		this.dateDeCreation = dateDeCreation;
	}
	
	
}
