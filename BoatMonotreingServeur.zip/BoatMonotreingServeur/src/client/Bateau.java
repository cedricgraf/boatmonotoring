package client;

import java.net.Socket;

public class Bateau {
	
private Socket client ;

private DonneesBateau donneesBateau;



public Socket getClient() {
	return client;
}



public void setClient(Socket client) {
	this.client = client;
}



public DonneesBateau getDonneesBateau() {
	return donneesBateau;
}



public void setDonneesBateau(DonneesBateau donneesBateau) {
	this.donneesBateau = donneesBateau;
}



public Bateau(String id, Socket client){
	
	this.client=client;
	this.donneesBateau= new DonneesBateau(id);
	
	
}
	
	

}
