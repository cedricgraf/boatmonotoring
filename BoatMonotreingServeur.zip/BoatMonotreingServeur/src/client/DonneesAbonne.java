package client;

import java.util.ArrayList;
import java.util.List;

public class DonneesAbonne {

		
	private String nom;
	private String prenom;
	private String login ;
	private String motDePasse;
	private  boolean estConnecte ;
	private ArrayList<String> listeOperations ;
	private ArrayList<String> listeEmails ;
	private ArrayList<Bateau> listeBateaux; 
	private String dateDeCreation ; 
	

	
	
	public boolean isEstConnecte() {
		return estConnecte;
	}


	public void setEstConnecte(boolean estConnecte) {
		this.estConnecte = estConnecte;
	}


	public  DonneesAbonne(String login,String pwd){
		
		this.login=login ;
		this.motDePasse=pwd ;
		this.estConnecte=true  ;
		
	}


	public String getLogin(){
		
		return 	this.login ;
	}


	public String getNom() {
		return nom;
	}




	public void setNom(String nom) {
		this.nom = nom;
	}




	public String getPrenom() {
		return prenom;
	}




	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}




	public String getMotDePasse() {
		return motDePasse;
	}




	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}






	public List<String> getListeOperations() {
		return listeOperations;
	}




	public void setListeOperations(ArrayList<String> listeOperations) {
		this.listeOperations = listeOperations;
	}




	public List<String> getListeEmails() {
		return listeEmails;
	}




	public void setListeEmails(ArrayList<String> listeEmails) {
		this.listeEmails = listeEmails;
	}




	public String getDateDeCreation() {
		return dateDeCreation;
	}




	public void setDateDeCreation(String dateDeCreation) {
		this.dateDeCreation = dateDeCreation;
	}
	
	
}
