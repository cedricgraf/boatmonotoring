package systeme;
import java.io.IOException;

import java.net.Socket;

/**
 * Processus de Transaction (anciennement ServeurSpecifique)
 */
class ProcessusRequete extends Thread {

	private Socket clientSocket;
	private ServeurTCP monServeurTCP;

	public  ProcessusRequete(Socket uneSocket, ServeurTCP unServeur) {        
		super("ServeurThread");
		clientSocket = uneSocket;
		System.out.println("[ProcessusTransaction] CLIENT : " + clientSocket);
		monServeurTCP = unServeur;
	} 

	public void run() {        
		monServeurTCP.getProtocole().execute( monServeurTCP.getContexte() , clientSocket);
		System.out.println("Processus de requ�tage fait");
	} 
}
