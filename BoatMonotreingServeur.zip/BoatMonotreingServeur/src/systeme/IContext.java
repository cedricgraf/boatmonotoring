package systeme;

public interface IContext {

}
