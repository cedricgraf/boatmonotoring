package systeme;

public interface ISurveillance extends IContext {

	public int demandeRetrait(int unRetrait);

	public int demandeDepot(int unDepot);
    


	public void setTypeOperation(String string);

	public void faireOperation(String string); 
     
}