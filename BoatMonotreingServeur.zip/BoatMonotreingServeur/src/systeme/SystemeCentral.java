package systeme;
import java.net.Socket;
import java.util.ArrayList;

import java.util.List;
import java.util.Observable;

import client.Abonne;
import client.Bateau;

/** La banque : dans cet exercice, une banque correspond a un compte bancaire unique,
 *  pour des raisons didactiques */
public class SystemeCentral extends Observable implements ISurveillance {

	private int port = 6666;
	private int hport = 7777;
	/** Les serveurs pour la mise en oeuvre de connexion a distance */
	public ArrayList<ServeurTCP> serveurs = new ArrayList<ServeurTCP>();
	
	
	/*  liste des abonnes*/
	
	ArrayList<Abonne> listeAbonnes ;
	ArrayList<Bateau> listeBateaux ;
	
	
	public ArrayList<Abonne> getListeAbonnes() {
		return listeAbonnes;
	}


	public void setListeAbonnes(ArrayList<Abonne> listeAbonnes) {
		this.listeAbonnes = listeAbonnes;
	}

	
	private ArrayList<String> historiqueOperations;
	
	
	public SystemeCentral() {

		listeAbonnes =new  ArrayList<Abonne>();
		listeBateaux = new  ArrayList<Bateau>(); 
	
		historiqueOperations = new ArrayList<String>();
								
	}
		
	
	public void lancerSystemeCentral() {
		serveurs.add(new ServeurTCP(this, new ProtocoleAbonne(), port ));
		serveurs.add(new ServeurTCP(this, new ProtocoleBateau(), hport));
		for(ServeurTCP s : serveurs ) {
				s.start();
		}
	}

	
	public ArrayList<String> getHistoriqueOperations() {
		return historiqueOperations;
	}
	
	
	public void ajouterAbonne(String nom, String prenom){
		this.listeAbonnes.add(new Abonne(nom,prenom)) ;
	}
	public void ajouterAbonne(String nom, String prenom,Socket client){
		this.listeAbonnes.add(new Abonne(nom,prenom,client)) ;
	}
	
	public void ajouterBateau(String id,Socket client){
		this.listeBateaux.add(new Bateau(id,client)) ;
	}
	
	
	
	public boolean demandeConnexionAbonne(String login, String pwd,Socket client){
		
					
			System.out.println(" Tentative de connexion ");
			return verification(login,pwd,client) ;

			

		
		
		
	}
	
	/*
	public boolean DemandeInscriptionAbonne(String requete){
	
	
	}
	*/
	
	public boolean verification(String login, String pwd,Socket socket){
		
		
		// on affiche tous les abonn�s 
		
		for( Abonne ab: getListeAbonnes()){
			
			
			System.out.println(" Ab "+ab.getDonneesAbonne().getNom()+"**");
			System.out.println(" Ab "+ab.getDonneesAbonne().getMotDePasse()+"**");
			
		}
			
		
		for (Abonne ab:this.listeAbonnes){
			if(ab.authentifier(login,pwd)){
				ab.setClientTcp(socket);
				ab.getDonneesAbonne().setEstConnecte(true);
				return true ;
			}
									
		}
		
		return false;				
	}

	@Override
	public int demandeRetrait(int unRetrait) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int demandeDepot(int unDepot) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setTypeOperation(String string) {
		// TODO Auto-generated method stub		
	}

	@Override
	public void faireOperation(String string) {
		// TODO Auto-generated method stub
		
	}
		
}
