package systeme;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;

import client.Abonne;



public class ProtocoleAbonne implements IProtocole {
	
	InputStream unInput;
	OutputStream unOutput;

	public void execute( IContext c ,Socket clientSocket ) {
		
		

		try {
			unInput = clientSocket.getInputStream();
			unOutput = clientSocket.getOutputStream();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		SystemeCentral sc = (SystemeCentral)c;
		String inputReq;
	
		BufferedReader is = new BufferedReader(new InputStreamReader(unInput));
		PrintStream os = new PrintStream(unOutput);
		int etat=0 ;
		try {
			String MessageExpediee ="";
			while ((inputReq = is.readLine()) != null&& etat!=3) {
				
				
				
				System.out.println(" Ordre Recu " + inputReq);
				String chaines[] = inputReq.split("-");
				
				if (chaines[0].contentEquals("inscription")) {
					
					System.out.println(" Tentative d'inscription ");//D
					
					

					sc.ajouterAbonne(chaines[1],chaines[2]);
					os.println("inscription-ok");		
					os.flush();				

				}
				
				if (chaines[0].contentEquals("Connexion")) {
						
			
					System.out.println(" Tentative de connexion ");
					
					if(sc.demandeConnexionAbonne(chaines[1],chaines[2],clientSocket)){
									

						os.println("connexion-ok");
						
				
						}
					
					
					else {

						
						os.println("connexion-erreur");		
						
						os.flush();						
					}
					
	
					
				
					
	
				}
				
				else {
					
					os.println(MessageExpediee);
					os.flush();
				
					
				}
				
			//os.println(MessageExpediee);
			
			
			}
		} catch ( Exception e) {
			System.out.println(" Pb d'exception ");
		}			
	}
}
