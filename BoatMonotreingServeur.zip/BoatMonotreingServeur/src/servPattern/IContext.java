package servPattern;

public interface IContext {

}
